import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {

  constructor() { 
    console.log("==============AngularBasicsComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============AngularBasicsComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============AngularBasicsComponent destroyed=============")
  }

}
