import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {

  title="Angular 12 Basics"; //string

  colors=['RED','GREEN','BLUE']; //array

  day=5;   //number
  min:number=1; //number
  max=8;  //number

  show:boolean=true; //boolean
  hide=false;   //boolean

  employee= {id:12,name:'Ram chinchole',salary:23455.5544433,variable:0.15,
  city:'Pune',mobile:'8149976894',pan:'cmxac9845d',
  doj:new Date(),isMarried:true,gender:1,age:33
 };//object


 time=new Observable<string>((s:Subscriber<string>)=>{
 
         setInterval(()=>{
          s.next(new Date().toLocaleString());
         },1000);
 });


 showHide(){
   this.hide=!this.hide;
 }

  constructor() { 
    console.log("==============AngularBasicsComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============AngularBasicsComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============AngularBasicsComponent destroyed=============")
  }

}
