import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.css']
})
export class CatalogComponent implements OnInit {

   title="Top 5 Technologies";  //string
   technologies=[
    {id:1,name:'Java',likes:0,dislikes:0},
    {id:2,name:'Spring Boot',likes:0,dislikes:0},
    {id:3,name:'Angular',likes:0,dislikes:0},
    {id:4,name:'React',likes:0,dislikes:0},
    {id:5,name:'Micto services',likes:0,dislikes:0},
   ]; //array


   incrementLikes(t:any){
     t.likes++;
   }

   incrementDislikes(t:any){
     t.dislikes++;
   }
   
  constructor() { 
    console.log("==============CatalogComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============CatalogComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============CatalogComponent destroyed=============")
  }


}
