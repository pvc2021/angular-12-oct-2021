import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.css']
})
export class CatalogComponent implements OnInit {

  constructor() { 
    console.log("==============CatalogComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============CatalogComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============CatalogComponent destroyed=============")
  }



}
