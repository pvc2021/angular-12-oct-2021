import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-number',
  //templateUrl: './number.component.html',

  template:`
             <div class='container'>
            
             <font color='blue' size="5">
             
             Number   :{{n}}
             
             </font>
            
             </div>
  
          `,
  styleUrls: ['./number.component.css']
})
export class NumberComponent implements OnInit {

   
n:number=0;


increment(){
  this.n=this.n+1;
}

decrement(){
  this.n=this.n-1;
}

  constructor() { 
    console.log("==============NumberComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============NumberComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============NumberComponent destroyed=============")
  }


}
