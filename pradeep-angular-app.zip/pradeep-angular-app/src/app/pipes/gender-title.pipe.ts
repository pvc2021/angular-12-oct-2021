import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gendertitle'
})
export class GenderTitlePipe implements PipeTransform {

  transform(isMarried: boolean,gender:number): string {
  
    if(isMarried && gender==1)
    return "Mr.";
    if(isMarried && gender==2)
    return "Mrs.";
    if(!isMarried && gender==1)
    return "Master.";
    if(!isMarried && gender==2)
    return "Miss.";
    return "";

  }

}
