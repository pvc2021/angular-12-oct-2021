import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlbumsService } from '../services/albums.service';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {

  title="All Albums"
  albums:any;
  message="";
  userId=0;

  constructor(private as:AlbumsService,private route:ActivatedRoute) { 
    console.log("==============PostsComponent created=============")
  }

  ngOnInit(): void {

  this.userId=this.route.snapshot.queryParams.userId;

  if(this.userId)
  this.getAllAlbumsByUserId()
  else
  this.getAllAlbums();
    console.log("==============PostsComponent initialized=============userId :"+this.userId)
  }

  ngOnDestroy(): void {
    console.log("==============PostsComponent destroyed=============")
  }


  getAllAlbums(){
    this.as.getAllalbums()
           .subscribe(response=>this.albums=response,
                      error=>this.message=error); 
              
  }

  getAllAlbumsByUserId(){
    this.as.getAllAlbumsByUserId(this.userId)
           .subscribe(response=>this.albums=response,
                      error=>this.message=error); 
             
  }

}
