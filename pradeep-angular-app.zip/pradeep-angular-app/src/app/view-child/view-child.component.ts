import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FgColorDirective } from '../directives/fg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {


 @ViewChild(NumberComponent) 
 private n:NumberComponent;


@ViewChild(FgColorDirective) 
private fg:FgColorDirective;


@ViewChild("name")  
private name:ElementRef<any>
@ViewChild("city")
private city:ElementRef<any>


 constructor() { }

  ngOnInit(): void {
  }


  incrementNumber(){

    this.n.increment();

  }
  
  decrementNumber(){
    this.n.decrement();
  }
  

  changeFgColor(){
    this.fg.fgColor="orange"; //it calls set FgColor method of FgColorDirective
  }


  changeColors(){
    this.name.nativeElement.style.color="RED";
    this.name.nativeElement.style.backgroundColor="yellow";
    
    this.city.nativeElement.style.color="brown";
    this.city.nativeElement.style.backgroundColor="wheat";

  }



}
