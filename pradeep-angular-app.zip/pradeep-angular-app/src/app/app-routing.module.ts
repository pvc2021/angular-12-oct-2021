import { NgModule, ViewChild } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlbumsComponent } from './albums/albums.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CatalogComponent } from './catalog/catalog.component';
import { CommentsComponent } from './comments/comments.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NestedComponent } from './nested/nested.component';
import { PhotosComponent } from './photos/photos.component';
import { PostsComponent } from './posts/posts.component';
import { RegisterComponent } from './register/register.component';
import { TodosComponent } from './todos/todos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
 {path:'home',component:HomeComponent},
 {path:'basics',component:AngularBasicsComponent},
 {path:'catalog',component:CatalogComponent},
 {path:'pipes',component:AngularPipesComponent},
 {path:'casestudy',component:CaseStudyComponent,
  
 children:[
  {path:'users',component:UsersComponent,

  children:[
    {path:'list',component:UsersListComponent},
    {path:'table',component:UsersTableComponent}
  ]
     },
  {path:'posts',component:PostsComponent},
  {path:'todos',component:TodosComponent},
  {path:'comments',component:CommentsComponent},
  {path:'albums',component:AlbumsComponent},
  {path:'photos',component:PhotosComponent},
  ]
 },
 {path:'login',component:LoginComponent},
 {path:'register',component:RegisterComponent},
 {path:'view-child',component:ViewChild},
 {path:'custom-directives',component:CustomDirectivesComponent},
 
 {path:'nested',component:NestedComponent},
 {path:'**',redirectTo:'home'},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
