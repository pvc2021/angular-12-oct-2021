import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //where to inject
  //template:'<h2><i>  {{title}}</i></h2>',// code is <=3 lines
  templateUrl: './app.component.html', //where to display code is >3 lines
  styleUrls: ['./app.component.css']// how to display
})
export class AppComponent {
  title = 'Welcome To Angular application at Softedge';// what to display
}
