import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  title="Users Table"
  users:any;
  message="";
  userId=0;
  user:any;

  constructor(private us:UsersService,private route:ActivatedRoute) { 
    console.log("==============UsersComponent created=============")
  }

  ngOnInit(): void {
    this.userId=this.route.snapshot.params.userId;

    if(this.userId)
    this.getUserById();
    console.log("==============UsersComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============UsersComponent destroyed=============")
  }


  getUserById(){
    this.us.getUserById(this.userId)
           .subscribe(response=>this.user=response,
                      error=>this.message=error); 
              
  }


}
