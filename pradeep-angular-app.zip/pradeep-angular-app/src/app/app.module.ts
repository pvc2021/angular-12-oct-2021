import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { CatalogComponent } from './catalog/catalog.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { CommentsComponent } from './comments/comments.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { NestedComponent } from './nested/nested.component';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';
import { CityComponent } from './city/city.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { HomeComponent } from './home/home.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { GenderPipe } from './pipes/gender.pipe';
import { GenderTitlePipe } from './pipes/gender-title.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import {Ng2SearchPipeModule} from "ng2-search-filter";
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { NumberComponent } from './number/number.component';
import { MustMatchDirective } from './directives/must-match.directive';
import { AddressModule } from './address/address.module';
import { CustomersComponent } from './customers/customers.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';


@NgModule({
  declarations: [ //The set of components, directives, and pipes (declarables) that belong to this module.
    AppComponent, AngularBasicsComponent, CatalogComponent, AngularPipesComponent, ViewChildComponent, LoginComponent, RegisterComponent, CaseStudyComponent, UsersComponent, PostsComponent, TodosComponent, CommentsComponent, AlbumsComponent, PhotosComponent, CustomDirectivesComponent, NestedComponent, CountryComponent, StateComponent, CityComponent, UsersListComponent, UsersTableComponent, HomeComponent, NavBarComponent, MainComponent, FooterComponent, GenderPipe, GenderTitlePipe, OrderByPipe, ParentComponent, ChildComponent, FgColorDirective, BgColorDirective, ShowDirective, HideDirective, NumberComponent, MustMatchDirective, CustomersComponent
  ],
  imports: [  //The set of NgModules whose exported declarables are available to templates in this module.
    BrowserModule,
    AppRoutingModule,
   // AddressModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ReactiveFormsModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    })
  ],
  providers: [],//The set of injectable objects that are available in the injector of this module. services
  
  //bootstrap: [AppComponent,AngularBasicsComponent,CatalogComponent],  //The set of components that are bootstrapped when this module is bootstrapped. The components listed here are automatically added to entryComponents.
  bootstrap: [AppComponent]  //The set of components that are bootstrapped when this module is bootstrapped. The components listed here are automatically added to entryComponents.

})
export class AppModule { }


