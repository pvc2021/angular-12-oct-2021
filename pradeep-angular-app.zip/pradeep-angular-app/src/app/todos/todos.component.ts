import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TodosService } from '../services/todos.service';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  title="All Albums"
  todos:any;
  message="";
  userId=0;

  constructor(private ts:TodosService,private route:ActivatedRoute) { 
    console.log("==============TodosComponent created=============")
  }

  ngOnInit(): void {

  this.userId=this.route.snapshot.queryParams.userId;

  if(this.userId)
  this.getAllTodosByUserId()
  else
  this.getAllTodos();
    console.log("==============TodosComponent initialized=============userId :"+this.userId)
  }

  ngOnDestroy(): void {
    console.log("==============TodosComponent destroyed=============")
  }


  getAllTodos(){
    this.ts.getAllTodos()
           .subscribe(response=>this.todos=response,
                      error=>this.message=error); 
              
  }

  getAllTodosByUserId(){
    this.ts.getAllTodosByUserId(this.userId)
           .subscribe(response=>this.todos=response,
                      error=>this.message=error); 
             
  }

}
