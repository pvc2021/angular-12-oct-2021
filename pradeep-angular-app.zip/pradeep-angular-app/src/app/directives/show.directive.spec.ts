import { ShowDirective } from './show.directive';

describe('ShowDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowDirective();
    expect(directive).toBeTruthy();
  });
});
