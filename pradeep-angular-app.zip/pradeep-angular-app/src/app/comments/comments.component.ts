import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommentsService } from '../services/comments.service';
import { PagerService } from '../services/pager.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {


  title="All Comments"  
  comments:any;
  message=""
  postId=0;
  
  
  // pager object
pager: any = {};

// paged items
pagedItems: any[];

  constructor(private ps:CommentsService,private route:ActivatedRoute,private pagerService:PagerService) {
      console.log("===========CommentsComponent created============");
     }
  
    ngOnDestroy(): void {
      console.log("===========CommentsComponent destroyed============");
     
    }
  
    ngOnInit(): void {

      this.postId=this.route.snapshot.queryParams.postId;

      console.log("===========CommentsComponent initialized============");
     if(this.postId)
     this.getAllCommentsByPostId();
     else     
     this.getAllComments();

    }
  
  
    getAllComments(){
      this.ps.getAllComments()
             .subscribe(response=>{this.comments=response;
            this.setPage(5);
            
            },error=>this.message=error);
    }
  
  
    getAllCommentsByPostId(){
      this.ps.getAllCommentsByPostId(this.postId)
             .subscribe(response=>{this.comments=response;
                          this.setPage(3);
            },error=>this.message=error);
    }
  
  

    setPage(page: number) {
      // get pager object from service
      this.pager = this.pagerService.getPager(this.comments.length, page,5);
  
      // get current page of items
      this.pagedItems = this.comments.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
  
  
}
