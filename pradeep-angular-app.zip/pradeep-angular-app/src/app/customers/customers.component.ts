import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../services/customers.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  title="Customers Table"
  customers:any;
  message="";
  customerId=0;
  customer:any;

  update=false;
  add=false;

  constructor(private cs:CustomersService) { 
    console.log("==============CustomersComponent created=============")
  }

  ngOnInit(): void {
    this.getAllCustomers();
    console.log("==============CustomersComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============CustomersComponent destroyed=============")
  }


  getAllCustomers(){
    this.cs.getAllCustomers()
           .subscribe(response=>this.customers=response,
                      error=>this.message=error); 
              
  }



  newCustomer(){
      
    this.customer={"customerId":0,
                  "name":"",
                  "pan":"",
                  "mobile":"",
                  "address":"",
                  "dob":""};

           this.add=false;
           this.update=true;

    }
  



  getCustomer(customerId:number){

    this.add=true;
    this.update=false;
           
      this.cs.getCustomerById(customerId)
             .subscribe(response=>this.customer=response,error=>this.message=error);
    }

    deleteCustomer(customerId:number){
      this.cs.deleteCustomerById(customerId)
             .subscribe(response=>this.getAllCustomers(),error=>this.message=error);
    }

   updateCustomer(customerId:number){
      this.cs.updateCustomerById(customerId,this.customer)
             .subscribe(response=>this.getAllCustomers(),error=>this.message=error);
             this.customer=null;
            
    }
   
   addCustomer(){
      this.cs.addCustomer(this.customer)
             .subscribe(response=>this.getAllCustomers(),error=>this.message=error);
    
            this.customer=null;

           }

}
