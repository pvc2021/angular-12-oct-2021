import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  message="Child Message";  //To send to parent

  @Input()
  parentMessage="";  //To get from parent

  @Output()
  childChanged=new EventEmitter<string>();


  constructor() { 
    console.log("==============ChildComponent created=============")
  }

  ngOnInit(): void {
    console.log("==============ChildComponent initialized=============")
  }

  ngOnDestroy(): void {
    console.log("==============ChildComponent destroyed=============")
  }


  sendMessageToParent(){
    this.childChanged.emit(this.message);
    console.log("================sendMessageToParent "+this.message);
  }

}
