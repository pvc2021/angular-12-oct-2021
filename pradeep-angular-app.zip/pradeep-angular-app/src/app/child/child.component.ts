import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  message="Child Message";  //To send to parent

  @Input()
  parentMessage="";  //To get from parent

  @Output()
  childChanged=new EventEmitter<string>();


   
  constructor() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent created   $$$$$$$$$$")
  }

  ngOnInit() {

  
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent initialized   $$$$$$$$$$")
  
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterViewInit  $$$$$$$$$$")
  }

  ngDoCheck() {
    console.log("############ ChildComponent  ngDoCheck #############");
  }


  sendMessageToParent(){
    this.childChanged.emit(this.message);
    console.log("================sendMessageToParent "+this.message);
  }

}
