import { TestBed } from '@angular/core/testing';

import { AgeService } from './age.service';

describe('AgeService', () => {
  let service: AgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return false for age below range ', () => {
    expect(service.validateAge(15)).toBeFalse();
  });

  it('should return false for age above range ', () => {
    expect(service.validateAge(67)).toBeFalse();
  });

  it('should return true for age within range ', () => {
    expect(service.validateAge(45)).toBeTruthy();
  });

  it('should return true for age lower bondry value ', () => {
    expect(service.validateAge(20)).toBeTruthy();
  });

  it('should return true for age upper boundry value ', () => {
    expect(service.validateAge(60)).toBeTruthy();
  });

});
