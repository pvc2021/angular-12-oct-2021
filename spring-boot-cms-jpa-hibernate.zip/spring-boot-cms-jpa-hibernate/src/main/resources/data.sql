insert into users(username, password, enabled)values('RAM','$2a$10$ge2ybXdrHWmY6qNWOkCaze2jAgTfeTovMsbUciUJCzIcfG/x.YGZi',true);
insert into authorities(username,authority)values('RAM','ROLE_ADMIN');
 
insert into users(username, password, enabled)values('RAHIM','$2a$10$ZuVLPUbpOc7Bxeu5GRdD4.XH0XWl4H6103a9OqNP58PTX/zqeGe1W',true);
insert into authorities(username,authority)values('RAHIM','ROLE_TEACHER');

insert into users(username, password, enabled)values('DAVID','$2a$10$9T6gPdQEug.dtrOorCwlVeQLd14OzZv649bGnl2fv3/jl4NZVc22u',true);
insert into authorities(username,authority)values('DAVID','ROLE_STUDENT');



insert into customers values(1,'Pradeep Chinchole','ampid9854d','9158652627','pradeepch82@gmail.com','Pune','2011-10-10');
insert into customers values(2,'Sachin Chinchole','ampid9854d','9158652627','sachin@gmail.com','Pune','2011-10-10');
insert into customers values(3,'Mohan Chinchole','ampid9854d','9158652627','mohan@gmail.com','Pune','2011-10-10');

