package com.pradeep.cms.data;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pradeep.cms.domain.Customer;

public enum CustomerMap {

INSTANCE;
	
	
private Map<Integer, Customer> map;

private CustomerMap() {

map=new HashMap<Integer, Customer>();

Customer c1=new Customer("Pradeep Chinchole","pxmdp9845f","91576525262","pradeepch82@gmail.com","Pune",new Date(1982,31,2));
Customer c2=new Customer("Amol Chinchole","pxmdp9845f","71576525262","amol@gmail.com","Pune",new Date(1981,11,7));
Customer c3=new Customer("Mahesh Chinchole","pxmdp9845f","81576525262","mahesh@gmail.com","Pune",new Date(1987,11,5));
Customer c4=new Customer("Vishal Chinchole","pxmdp9845f","91576525262","vishal@gmail.com","Mumbai",new Date(1986,21,6));


map.put(c1.getCustomerId(), c1);
map.put(c2.getCustomerId(), c2);
map.put(c3.getCustomerId(), c3);
map.put(c4.getCustomerId(), c4);

	
	
}
	
public Map<Integer, Customer> getMap() {
	return map;
}
}
